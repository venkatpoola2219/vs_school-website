import React from "react";

export default function TopBar() {
  return <div className="topbar"><div className="topbar-inner">
    <a className="top-phone" href="tel:7600800500">7600800500</a>
    <a className="top-offer" href="#admissions">Enquire Now for Early Bird Benefits</a>
    <a className="top-admission" href="#schools">Delhi Admission</a>
    <div className="top-socials">
      <a href="#" aria-label="Facebook"><i className="bi bi-facebook" /></a>
      <a href="#" aria-label="Instagram"><i className="bi bi-instagram" /></a>
      <a href="#" aria-label="LinkedIn"><i className="bi bi-linkedin" /></a>
      <a href="#" aria-label="X"><i className="bi bi-twitter-x" /></a>
      <a href="#" aria-label="YouTube"><i className="bi bi-youtube" /></a>
    </div>
  </div></div>;
}
