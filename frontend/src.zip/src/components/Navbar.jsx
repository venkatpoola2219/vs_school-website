// import { useState } from "react";
// import siteImages from "../config/siteImages";
// const links = [["About Us","#about"],["Academics","#academics"],["Admissions","#admissions"],["Student Life","#student-life"],["Parents Corner","#parents"],["Alumni Connect","#alumni"]];
// export default function Navbar() {
//   const [open,setOpen] = useState(false);
//   return <header className="site-header">
//     <a className="school-logo" href="#home" aria-label="School home">
//       {siteImages.logo ? <img src={siteImages.logo} alt="School logo" /> : <span className="logo-placeholder"><b className="logo-mark">✳</b><strong>YOUR SCHOOL</strong><small>GROUP OF INSTITUTIONS</small></span>}
//     </a>
//     <nav className={`main-navigation ${open ? "is-open" : ""}`}>
//       {links.map(([label,href]) => <a key={label} href={href} onClick={()=>setOpen(false)}>{label}</a>)}
//     </nav>
//     <button className={`menu-toggle ${open ? "active" : ""}`} onClick={()=>setOpen(!open)} aria-label="Toggle menu" aria-expanded={open}><span/><span/><span/></button>
//   </header>;
// }



import React, { useState } from "react";
import siteImages from "../config/siteImages";

const links = [
  ["About Us", "#about"],
  ["Academics", "#academics"],
  ["Admissions", "#admissions"],
  ["Student Life", "#student-life"],
  ["Parents Corner", "#parents"],
  ["Alumni Connect", "#alumni"]
];

export default function Navbar() {
  const [open, setOpen] = useState(false);

  return (
    <header className="site-header">
      <a className="school-logo" href="#home" aria-label="School home">
        {siteImages.logo ? (
          <img src={siteImages.logo} alt="School logo" />
        ) : (
          <span className="logo-placeholder">
            <b className="logo-mark">✳</b>
            <strong>YOUR SCHOOL</strong>
            <small>GROUP OF INSTITUTIONS</small>
          </span>
        )}
      </a>

      <nav className={`main-navigation ${open ? "is-open" : ""}`}>
        {links.map(([label, href]) => (
          <a key={label} href={href} onClick={() => setOpen(false)}>
            {label}
          </a>
        ))}
      </nav>

      <button
        className={`menu-toggle ${open ? "active" : ""}`}
        onClick={() => setOpen(!open)}
        aria-label="Toggle menu"
        aria-expanded={open}
      >
        <span></span>
        <span></span>
        <span></span>
      </button>
    </header>
  );
}
