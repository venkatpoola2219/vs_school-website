import React from "react";
export default function Footer() {
  return <> <footer className="site-footer">
    <div className="footer-inner">
      <strong>Your School Name</strong>
      <span>Inspiring learners. Building brighter futures.</span>
      <a href="tel:7600800500">7600800500</a>
    </div>
  </footer>;</>
}
