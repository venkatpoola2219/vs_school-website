import React from "react";
import TopBar from "./components/TopBar";
import Navbar from "./components/Navbar";
import ChatButton from "./components/ChatButton";
import Footer from "./components/Footer";
import Hero from "./sections/Hero";
import SchoolFinder from "./sections/SchoolFinder";
export default function App() {
  return <>
    <TopBar/><div className="hero-shell"><Navbar/><Hero/><SchoolFinder/><ChatButton/></div>
    <section id="about" className="content-section"><span className="section-eyebrow">ABOUT US</span><h2>Learning that inspires every child</h2><p>Replace this text with your school's story, vision and achievements.</p></section>
    <section id="academics" className="content-section content-muted"><span className="section-eyebrow">ACADEMICS</span><h2>Discover a world of learning</h2><p>Add your curriculum, programmes and academic information here.</p></section>
    <section id="student-life" className="content-section"><span className="section-eyebrow">STUDENT LIFE</span><h2>More than learning inside a classroom</h2><p>Add sports, arts, activities and student achievements here.</p></section>
    <section id="admissions" className="content-section content-muted"><span className="section-eyebrow">ADMISSIONS</span><h2>Start your admission journey</h2><p>Connect this section to your existing admission enquiry form or add admission contact details.</p><a className="section-button" href="tel:7600800500">Call admissions</a></section>
    <section id="parents" className="content-section"><span className="section-eyebrow">PARENTS CORNER</span><h2>A connected school community</h2><p>Add parent resources, updates and useful links here.</p></section>
    <section id="alumni" className="content-section content-muted"><span className="section-eyebrow">ALUMNI CONNECT</span><h2>Once a learner, always part of our community</h2><p>Add alumni news and success stories here.</p></section>
    <Footer/>
  </>;
}
