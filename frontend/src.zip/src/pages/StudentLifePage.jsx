import React from "react";
import Life from "../sections/Life";

export default function StudentLifePage() {
  return <Life />;
}
