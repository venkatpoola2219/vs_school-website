import React from "react";
export default function AcademicsPage() {
  return <section id="academics" className="section-pad soft-bg">
    <div className="container">
      <span className="eyebrow">ACADEMICS</span>
      <h2 className="section-title">A strong foundation for <em>every learner.</em></h2>
      <p className="body-copy">Our curriculum encourages curiosity, creativity and confident learning at every stage.</p>
    </div>
  </section>;
}
