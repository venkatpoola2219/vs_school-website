import React from "react";
import AboutSection from "../sections/AboutSection";
import Statistics from "../sections/Statistics";
import Approach from "../sections/Approach";
import Awards from "../sections/Awards";

export default function AboutPage() {
  return <><AboutSection /><Statistics /><Approach /><Awards /></>;
}
