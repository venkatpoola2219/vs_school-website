import React from "react";
import Enquiry from "../sections/Enquiry";

export default function AdmissionsPage() {
  return <Enquiry />;
}
