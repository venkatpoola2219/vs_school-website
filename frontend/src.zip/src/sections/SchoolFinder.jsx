import React from "react";
import { useState } from "react";
import siteImages from "../config/siteImages";
const boards=["CBSE","ICSE","IB","Cambridge"], cities=["Delhi","Mumbai","Hyderabad","Bengaluru","Pune","Chennai"], schools=["Ryan International School","Ryan Global School"];
export default function SchoolFinder() {
  const [board,setBoard]=useState(""), [city,setCity]=useState(""), [school,setSchool]=useState(""), [message,setMessage]=useState("");
  function submit(e) { e.preventDefault(); if(!board||!city||!school) return setMessage("Please select a board, city and school."); setMessage(`Thank you! Showing ${school} options in ${city} (${board}).`); }
  return <section id="schools" className="finder-position">
    <div className="school-finder" style={siteImages.schoolFinderBackground?{backgroundImage:`linear-gradient(90deg,rgba(20,30,20,.72),rgba(20,30,20,.52)),url("${siteImages.schoolFinderBackground}")`}:undefined}>
      <h2>Find a school near you!</h2>
      <form className="finder-controls" onSubmit={submit}>
        <label><span className="visually-hidden">Board</span><select value={board} onChange={e=>setBoard(e.target.value)}><option value="">Select Board</option>{boards.map(x=><option key={x}>{x}</option>)}</select></label>
        <label><span className="visually-hidden">City</span><select value={city} onChange={e=>setCity(e.target.value)}><option value="">Select City</option>{cities.map(x=><option key={x}>{x}</option>)}</select></label>
        <label><span className="visually-hidden">School</span><select value={school} onChange={e=>setSchool(e.target.value)}><option value="">Select School</option>{schools.map(x=><option key={x}>{x}</option>)}</select></label>
        <button type="submit">Find</button>
      </form>
      {message&&<p className="finder-message" role="status">{message}</p>}
    </div>
  </section>;
}
