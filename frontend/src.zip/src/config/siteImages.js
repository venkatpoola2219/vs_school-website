// Paste your direct image URLs between the quotes.
// Transparent PNGs work best for heroPlane, heroStudent and anniversaryBadge.
const siteImages = {
  logo: "https://www.ryangroup.org/public/images/front_end/SiteSetting/ryan-group-logo_1628517995.png",
  heroBackground: "https://www.ryangroup.org/public/images/front_end/corporate/banner/desktop-banner-b2.webp",
  heroPlane: "",
  heroStudent: "",
  anniversaryBadge: "",
  schoolFinderBackground: ""
};
export default siteImages;
